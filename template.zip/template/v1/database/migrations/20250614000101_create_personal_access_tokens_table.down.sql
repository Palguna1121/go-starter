-- Drop personal_access_tokens table
DROP TABLE IF EXISTS personal_access_tokens;